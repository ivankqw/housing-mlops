# Project Presentation Video

The video should summarise the work done and evidence the deliverable in a concise fiveminute presentation with the intent of sharing the knowledge and skills that your group has 
learnt with your peers. If you are working on a real-world project related to your workplace, 
please do not share any confidential information. 
The video can be recorded with any tool and in any format. 