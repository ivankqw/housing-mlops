DATA_PATH = "/opt/airflow/data/"

ADDRESSES_CSV = "addresses.csv"
ONEMAP_API_URL = "https://www.onemap.gov.sg/api/common/elastic/search"
URA_ACCESS_KEY = "480de617-6aee-4c71-a04a-3b6c3a9596b2"